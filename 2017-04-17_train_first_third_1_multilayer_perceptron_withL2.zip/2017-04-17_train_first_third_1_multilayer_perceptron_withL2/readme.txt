training: 15200
testing: 2+1, 1+2: 3000
hidden_features: 5

accuracy 0.5
